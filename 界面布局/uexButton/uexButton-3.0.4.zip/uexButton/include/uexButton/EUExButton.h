//
//  EUExButton.h
//  EUExButton
//
//  Created by AppCan on 14-10-11.
//  Copyright (c) 2014年 AppCan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EUExBase.h"

@interface EUExButton : EUExBase

@end
