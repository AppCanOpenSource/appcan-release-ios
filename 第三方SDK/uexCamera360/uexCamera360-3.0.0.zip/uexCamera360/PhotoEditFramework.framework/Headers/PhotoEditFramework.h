//
//  PhotoEditFramework.h
//  PhotoEditFramework
//
//  Created by Cc on 14-7-30.
//  Copyright (c) 2014年 Cc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


//! Project version number for PhotoEditFramework.
FOUNDATION_EXPORT double PhotoEditFrameworkVersionNumber;

//! Project version string for PhotoEditFramework.
FOUNDATION_EXPORT const unsigned char PhotoEditFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PhotoEditFramework/PublicHeader.h>

#import <PhotoEditFramework/pg_edit_sdk_controller.h>
