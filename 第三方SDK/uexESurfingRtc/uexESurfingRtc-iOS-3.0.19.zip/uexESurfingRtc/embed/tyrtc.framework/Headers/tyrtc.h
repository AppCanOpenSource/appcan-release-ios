//
//  tyrtc.h
//  tyrtc
//
//  Created by ding on 2017/1/4.
//  Copyright © 2017年 tyrtc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for tyrtc.
FOUNDATION_EXPORT double tyrtcVersionNumber;

//! Project version string for tyrtc.
FOUNDATION_EXPORT const unsigned char tyrtcVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <tyrtc/PublicHeader.h>


