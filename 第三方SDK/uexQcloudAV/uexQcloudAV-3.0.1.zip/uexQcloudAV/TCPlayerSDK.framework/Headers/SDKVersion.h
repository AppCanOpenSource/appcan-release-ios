#ifndef TCPlayerSDK_VERSION_H
#define TCPlayerSDK_VERSION_H
#define TCPlayerSDK_VERSION Unversioned directory
#endif
