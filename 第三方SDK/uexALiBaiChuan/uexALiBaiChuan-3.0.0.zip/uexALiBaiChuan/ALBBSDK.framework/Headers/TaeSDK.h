//
//  TaeSDK.h
//  ALBBSDK
//
//  Created by liqing on 15/10/19.
//  Copyright © 2015年 alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ALBBSDK.h"

__attribute((deprecated("use ALBBSDK instead."))) @interface TaeSDK : ALBBSDK
@end
